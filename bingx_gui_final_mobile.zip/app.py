
import os, time, hmac, hashlib, json, requests
from flask import Flask, render_template_string, jsonify, request

app = Flask(__name__)

API_KEY = "2RIq4KBDyO3tqNyHsFxNy5cQOuYtXuykKWZEJ4XJbOoygr859uQEF4xoBCIln6T02U7D3VvmWnYQtbrEaBkw"
API_SECRET = "G1zpIw5djZb2BZcqHZup68iqY6Nu3D2do7qx1UknvMcsDTguMusvZy3Kxa6uJwMOpA9PdH6GVn1uh0LfOxQ"
BASE_URL = "https://open-api.bingx.com"

def create_signature(params):
    query_string = "&".join(f"{k}={params[k]}" for k in sorted(params))
    return hmac.new(API_SECRET.encode(), query_string.encode(), hashlib.sha256).hexdigest()

def get_btc_price():
    try:
        endpoint = "/openApi/spot/v1/ticker/24hr"
        url = BASE_URL + endpoint
        ts = int(time.time() * 1000)
        params = {"symbol": "BTC-USDT", "timestamp": ts}
        params["signature"] = create_signature(params)
        headers = {"X-BX-APIKEY": API_KEY}
        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        return float(data["data"][0]["lastPrice"]) if data.get("code") == 0 else 0.0
    except Exception as e:
        print("BTC 가격 오류:", e)
        return 0.0

def get_futures_usdt_balance():
    try:
        endpoint = "/openApi/swap/v2/user/balance"
        url = BASE_URL + endpoint
        timestamp = int(time.time() * 1000)
        params = {"timestamp": timestamp}
        params["signature"] = create_signature(params)
        headers = {"X-BX-APIKEY": API_KEY}
        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        balance_data = data.get("data", {}).get("balance", {})
        return float(balance_data.get("balance", 0.0))
    except Exception as e:
        print("잔고 오류:", e)
        return 0.0

@app.route("/get_data")
def get_data():
    return jsonify({
        "btc_price": get_btc_price(),
        "usdt_balance": get_futures_usdt_balance()
    })

@app.route("/place_order", methods=["POST"])
def place_order():
    data = request.get_json()
    print("주문요청:", data)
    return jsonify({"success": True})

index_html = """
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>BingX Manual Trader</title>
<style>
body { font-family: Arial; margin:0; padding:10px; background:#f4f4f4; }
.status { text-align:center; margin-bottom:10px; font-size:16px; }
.container { display:flex; flex-direction:column; gap:10px; }
.panel { background:#fff; border-radius:8px; padding:10px; box-shadow:0 2px 5px rgba(0,0,0,0.1); }
.panel h3 { margin:0 0 10px 0; text-align:center; }
table { width:100%; border-collapse:collapse; font-size:13px; }
td { padding:4px; text-align:center; }
input, button { width:100%; padding:6px; font-size:13px; }
button { background:#007bff; color:#fff; border:none; border-radius:4px; margin-top:5px; }
</style></head>
<body>
<div class="status">
  BTC 현재가: <span id="btc_price">-</span> USDT<br>
  보유 USDT: <span id="usdt_balance">-</span>
</div>
<div class="container">
  <div class="panel">
    <h3>LONG</h3>
    <table>
      <tr><td><input id="order_long" placeholder="진입 USDT"></td></tr>
      <tr><td><button onclick="exec('order_long')">진입</button></td></tr>
    </table>
  </div>
  <div class="panel">
    <h3>SHORT</h3>
    <table>
      <tr><td><input id="order_short" placeholder="진입 USDT"></td></tr>
      <tr><td><button onclick="exec('order_short')">진입</button></td></tr>
    </table>
  </div>
</div>
<script>
function exec(id){
  fetch("/place_order", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({ order: id })
  }).then(r=>r.json()).then(d=>{
    if(d.success) alert(id + " 주문 완료");
  });
}
setInterval(()=>{
  fetch("/get_data").then(r=>r.json()).then(d=>{
    document.getElementById("btc_price").innerText = d.btc_price.toFixed(2);
    document.getElementById("usdt_balance").innerText = d.usdt_balance.toFixed(2);
  });
}, 5000);
</script></body></html>
"""

@app.route("/")
def home():
    return render_template_string(index_html)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
