import os, requests, time, hmac, hashlib
from flask import Flask, render_template_string, jsonify, request

app = Flask(__name__)

API_KEY = "2RIq4KBDyO3tqNyHsFxNy5cQOuYtXuykKWZEJ4XJbOoygr859uQEF4xoBCIln6T02U7D3VvmWnYQtbrEaBkw"
API_SECRET = "G1zpIw5djZb2BZcqHZup68iqY6Nu3D2do7qx1UknvMcsDTguMusvZy3Kxa6uJwMOpA9PdH6GVn1uh0LfOxQ"
BASE_URL = "https://open-api.bingx.com"

def create_signature(params):
    query_string = "&".join(f"{k}={params[k]}" for k in sorted(params))
    return hmac.new(API_SECRET.encode(), query_string.encode(), hashlib.sha256).hexdigest()

def get_btc_price():
    endpoint = "/openApi/spot/v1/ticker/24hr"
    url = BASE_URL + endpoint
    timestamp = int(time.time() * 1000)
    params = {"symbol": "BTC-USDT", "timestamp": timestamp}
    params["signature"] = create_signature(params)
    headers = {"X-BX-APIKEY": API_KEY}
    try:
        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        if data.get("code") == 0 and isinstance(data.get("data"), list):
            return float(data["data"][0]["lastPrice"])
    except Exception as e:
        print("⚠️ BTC 가격 조회 오류:", e)
    return 0.0

def get_futures_balance():
    endpoint = "/openApi/swap/v2/user/balance"
    url = BASE_URL + endpoint
    timestamp = int(time.time() * 1000)
    params = {"timestamp": timestamp}
    params["signature"] = create_signature(params)
    headers = {"X-BX-APIKEY": API_KEY}
    try:
        response = requests.get(url, headers=headers, params=params)
        data = response.json()
        balance_info = data.get("data", {}).get("balance", {})
        return float(balance_info.get("balance", 0.0))
    except Exception as e:
        print("❌ 선물 잔고 조회 오류:", e)
    return 0.0

@app.route("/get_data")
def get_data():
    return jsonify({
        "btc_price": get_btc_price(),
        "usdt_balance": get_futures_balance()
    })

@app.route("/place_order", methods=["POST"])
def place_order():
    data = request.get_json()
    print("📥 주문 요청:", data)
    return jsonify({"success": True})

index_html = """<!DOCTYPE html>
<html lang='ko'>
<head>
  <meta charset='UTF-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
  <title>BingX GUI</title>
  <style>
    body { font-family:sans-serif; padding:10px; background:#f4f4f4; }
    .status { text-align:center; margin-bottom:10px; font-weight:bold; }
    .container { display:flex; flex-wrap:wrap; gap:10px; justify-content:center; }
    .panel { background:white; padding:10px; border-radius:8px; box-shadow:0 0 5px #ccc; min-width:300px; max-width:400px; }
    table { width:100%; border-collapse:collapse; }
    td { padding:6px; border:1px solid #ccc; text-align:center; }
    input, button { width:90%; padding:5px; }
    button { background:#007bff; color:white; border:none; border-radius:4px; }
    .highlight { color:red; font-weight:bold; }
  </style>
</head>
<body>
<div class='status'>💰 BTC 가격: <span id='btc_price'>-</span> | USDT 잔고: <span id='usdt_balance'>-</span></div>
<div class='container'>
  <div class='panel'><h3>LONG</h3><table>
    <tr><td>매수</td><td><input id='buy1'><button onclick="exec('buy1')">실행</button></td></tr>
    <tr><td>추가매수</td><td><input id='buy2'><button onclick="exec('buy2')">실행</button></td></tr>
    <tr><td colspan='2'><button onclick="exec('sell_all')">전량매도</button></td></tr>
  </table></div>
  <div class='panel'><h3>SHORT</h3><table>
    <tr><td>매도</td><td><input id='sell1'><button onclick="exec('sell1')">실행</button></td></tr>
    <tr><td>추가매도</td><td><input id='sell2'><button onclick="exec('sell2')">실행</button></td></tr>
    <tr><td colspan='2'><button onclick="exec('buy_all')">전량매수</button></td></tr>
  </table></div>
</div>
<script>
function exec(id){
  fetch("/place_order", {
    method: "POST", headers: {"Content-Type":"application/json"},
    body: JSON.stringify({order: id})
  }).then(r=>r.json()).then(data=>{
    if(data.success){
      let el=document.getElementById(id); if(el) el.classList.add("highlight");
    }
  });
}
setInterval(()=>{ fetch("/get_data").then(r=>r.json()).then(d=>{
  document.getElementById("btc_price").innerText = d.btc_price.toFixed(2);
  document.getElementById("usdt_balance").innerText = d.usdt_balance.toFixed(2);
}); }, 3000);
</script>
</body>
</html>"""

@app.route("/")
def home():
    return render_template_string(index_html)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)